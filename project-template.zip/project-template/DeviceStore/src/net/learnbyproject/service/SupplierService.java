/* Copyright (C) learnbyproject.net - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Sera.Ng <contact@learnbyproject.net>, September 2019
 */
package net.learnbyproject.service;

public class SupplierService {
    
}
