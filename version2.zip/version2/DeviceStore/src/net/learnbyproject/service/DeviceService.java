package net.learnbyproject.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Vector;
import net.learnbyproject.dto.Device;
import net.learnbyproject.dto.Supplier;

public class DeviceService {

    public static int countAllDevices() throws SQLException {
        String select = "select count(*) as total from device";
        try (Connection c = DBService.openConnection();
                Statement st = c.createStatement();
                ResultSet rs = st.executeQuery(select)) {
            if (rs.next()) {
                return rs.getInt("total");
            }
        }
        return 0;
    }

    public static Vector<Device> loadPagingDevices(int pageSize, int offset) throws SQLException {
        String select = "select * from device limit ? offset ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setInt(1, pageSize);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            return buildDeviceList(rs);
        }
    }

    public static Vector<Device> loadAllDevices() throws SQLException {
        Vector<Device> deviceList = new Vector<>();
        String select = "select * from device";
        try (Connection c = DBService.openConnection();
                Statement st = c.createStatement();
                ResultSet rs = st.executeQuery(select)) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                int quantity = rs.getInt("quantity");
                float price = rs.getFloat("price");
                Date importedDate = rs.getDate("imported_date");
                Supplier supplier = SupplierService.findSupplierById(rs.getString("supplier_id"));
                // Create a new device
                Device dev = new Device(id, name, quantity, price, importedDate, supplier);
                deviceList.add(dev);
            }
        }
        return deviceList;
    }

    public static boolean isDeviceExited(String id) throws SQLException {
        String select = "select id from device where id = ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public static int insertDevice(Device device) throws SQLException {
        String query = "insert into device values(?,?,?,?,?,?)";
        try (Connection conn = DBService.openConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, device.getId());
            ps.setString(2, device.getName());
            ps.setInt(3, device.getQuantity());
            ps.setFloat(4, device.getPrice());
            ps.setDate(5, device.getImportedDate());
            ps.setString(6, device.getSupplier().getId());
            return ps.executeUpdate();
        }
    }

    public static int updateDevice(Device device) throws SQLException {
        String query = "update device set name = ?, quantity = ?, price = ?, imported_date = ?, supplier_id = ? where id = ?";
        try (Connection conn = DBService.openConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, device.getName());
            ps.setInt(2, device.getQuantity());
            ps.setFloat(3, device.getPrice());
            ps.setDate(4, device.getImportedDate());
            ps.setString(5, device.getSupplier().getId());
            ps.setString(6, device.getId());
            return ps.executeUpdate();
        }
    }

    public static int[] removeDevice(List<String> ids) throws SQLException {
        String query = "delete from device where id = ?";
        try (Connection conn = DBService.openConnection();
                PreparedStatement ps = conn.prepareStatement(query);) {
            for (String id : ids) {
                ps.setString(1, id);
                ps.addBatch();
            }

            return ps.executeBatch();
        }
    }

    public static Vector<Device> findDeviceByName(String devName) throws SQLException {

        String select = "select * from device where name like ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setString(1, "%" + devName + "%");
            ResultSet rs = ps.executeQuery();
            return buildDeviceList(rs);
        }
    }

    public static Vector<Device> findDeviceByName(String devName, String dateFrom, String dateTo, String supName) throws SQLException {

        String select = "select d.* from device d, supplier s where d.name like ? and "
                + "(d.imported_date >= ? and d.imported_date <= ?) "
                + "and d.supplier_id = s.id and s.name like ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setString(1, "%" + devName + "%");
            ps.setString(2, dateFrom);
            ps.setString(3, dateTo);
            ps.setString(4, "%" + supName + "%");
            ResultSet rs = ps.executeQuery();
            return buildDeviceList(rs);
        }
    }

    public static Vector<Device> buildDeviceList(ResultSet rs) throws SQLException {
        Vector<Device> devices = new Vector<>();
        while (rs.next()) {
            Supplier supplier = SupplierService.findSupplierById(rs.getString("supplier_id"));
            Device dev = new Device(rs.getString("id"), rs.getString("name"),
                    rs.getInt("quantity"), rs.getFloat("price"),
                    rs.getDate("imported_date"), supplier);
            devices.add(dev);
        }
        return devices;
    }

}
