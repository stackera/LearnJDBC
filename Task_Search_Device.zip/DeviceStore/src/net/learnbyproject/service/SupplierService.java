/* Copyright (C) learnbyproject.net - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Sera.Ng <contact@learnbyproject.net>, September 2019
 */
package net.learnbyproject.service;

import java.sql.*;
import java.util.Vector;
import net.learnbyproject.dto.Supplier;

public class SupplierService {
    public static Supplier findSupplierById(String id) throws SQLException {
        Supplier supplier = null;
        String select = "select * from supplier where id = ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    supplier = new Supplier(rs.getString("id"), rs.getString("name"), rs.getString("address"));
                }
            }
        }
        return supplier;
    }
    
    public static Vector<Supplier> loadAllSuppliers() throws SQLException {
        Vector<Supplier> supplierList = new Vector<>();
        String select = "select * from supplier";
        try (Connection c = DBService.openConnection();
                Statement st = c.createStatement();
                ResultSet rs = st.executeQuery(select)) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                String address = rs.getString("address");
                Supplier supplier = new Supplier(id, name, address);
                supplierList.add(supplier);
            }
        } 
        return supplierList;
    }
    
    public static boolean isSupplierExited(String id) throws SQLException{
        String select = "select id from supplier where id = ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } 
    }
    
    public static int insertSupplier(Supplier supplier) throws SQLException {
        String query = "insert into supplier values(?,?,?)";
        try (Connection conn = DBService.openConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, supplier.getId());
            ps.setString(2, supplier.getName());
            ps.setString(3, supplier.getAddress());
            return ps.executeUpdate();           
        } 
    }
    
    public static int updateSupplier(Supplier supplier) throws SQLException {
        String query = "update supplier set name = ?, address = ? where id = ?";
        try (Connection conn = DBService.openConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, supplier.getName());
            ps.setString(2, supplier.getAddress());
            ps.setString(3, supplier.getId());
            return ps.executeUpdate();
        } 
    }
    
    public static boolean isSupplierExitedInDevice(String supId) throws SQLException {
        String select = "select id from device where supplier_id = ?";
        try (Connection c = DBService.openConnection();
                PreparedStatement ps = c.prepareStatement(select);) {
            ps.setString(1, supId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
    
    public static int removeSupplier(String id) throws SQLException {
        String query = "delete from supplier where id = ?";
        try (Connection conn = DBService.openConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, id);
            return ps.executeUpdate();
        } 
    }
}
