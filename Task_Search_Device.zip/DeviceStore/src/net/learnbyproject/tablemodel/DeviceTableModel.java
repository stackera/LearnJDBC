/* Copyright (C) learnbyproject.net - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Sera.Ng <contact@learnbyproject.net>, September 2019
 */
package net.learnbyproject.tablemodel;

import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import net.learnbyproject.dto.Device;

public class DeviceTableModel extends AbstractTableModel {

    Vector<String> header = new Vector<>();
    Vector<Device> data = new Vector<Device>();

    public DeviceTableModel() {
        // Init table header
        this.header.add("ID");
        this.header.add("Name");
        this.header.add("Quantity");
        this.header.add("Price");
        this.header.add("Imported Date");
        this.header.add("Supplier");
    }

    public Vector<Device> getData() {
        return data;
    }

    public void setData(Vector<Device> data) {
        this.data = data;
    }

    @Override
    public String getColumnName(int column) {
        return header.get(column);
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return header.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Device device = data.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return device.getId();
            case 1:
                return device.getName();
            case 2:
                return device.getQuantity();
            case 3:
                return device.getPrice();
            case 4:
                return device.getImportedDate();
            case 5:
                return device.getSupplier().getName();
        }
        return null;
    }

}
