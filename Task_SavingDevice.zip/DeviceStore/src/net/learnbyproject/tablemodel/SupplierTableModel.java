/* Copyright (C) learnbyproject.net - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Sera.Ng <contact@learnbyproject.net>, September 2019
 */
package net.learnbyproject.tablemodel;

import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import net.learnbyproject.dto.Supplier;

public class SupplierTableModel extends AbstractTableModel {

    Vector<String> header = new Vector<>();
    Vector<Supplier> data = new Vector<Supplier>();

    public SupplierTableModel() {
        // Init table header
        this.header.add("ID");
        this.header.add("Name");
        this.header.add("Address");
    }

    public Vector<Supplier> getData() {
        return data;
    }

    public void setData(Vector<Supplier> data) {
        this.data = data;
    }
    
    @Override
    public String getColumnName(int column) {
        return header.get(column);
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return header.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Supplier supplier = data.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return supplier.getId();
            case 1:
                return supplier.getName();
            case 2:
                return supplier.getAddress();
        }
        return null;
    }
}
