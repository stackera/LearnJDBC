/* Copyright (C) learnbyproject.net - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Sera.Ng <contact@learnbyproject.net>, September 2019
 */
package net.learnbyproject.service;

import java.sql.*;
import java.util.Vector;
import net.learnbyproject.dto.Device;
import net.learnbyproject.dto.Supplier;

public class DeviceService {
    public static Vector<Device> loadAllDevices() throws SQLException {
        Vector<Device> deviceList = new Vector<>();
        String select = "select * from device";
        try (Connection c = DBService.openConnection();
                Statement st = c.createStatement();
                ResultSet rs = st.executeQuery(select)) {
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("name");
                int quantity = rs.getInt("quantity");
                float price = rs.getFloat("price");
                Date importedDate = rs.getDate("imported_date");
                Supplier supplier = SupplierService.findSupplierById(rs.getString("supplier_id"));
                // Create a new device
                Device dev = new Device(id, name, quantity, price, importedDate, supplier);
                deviceList.add(dev);
            }
        }
        return deviceList;
    }
    
}
