/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.learnbyproject.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DBService {
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/devicedb?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";
    private static final String DATE_PATTERN = "yyyy-MM-dd";
    public static Connection openConnection() {
        try {
            Class.forName(DRIVER);
            Connection c = DriverManager.getConnection(URL, USER, PASSWORD);
            return c;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public static String getFormattedDate(Date date) {
        return new SimpleDateFormat(DATE_PATTERN).format(date);
    }
    
    public static Date getFormattedDate(String date) throws ParseException{
        SimpleDateFormat sf = new SimpleDateFormat(DATE_PATTERN);
        java.util.Date parsedDate = sf.parse(date);
        return new Date(parsedDate.getTime());
    }
}
